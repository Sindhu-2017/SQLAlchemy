from typing import Protocol
from decimal import Decimal
from models.income_expense import Income, Expense

class IncomeRepositoryInterface(Protocol):
    def get_by_id(self, income_id: int) -> Income | None:
        ...

    def create(self, income: Income) -> Income:
        ...

    def update(self, income: Income) -> Income:
        ...

    def delete(self, income: Income) -> None:
        ...

    def get_all(self,page: int,page_size: int,income_name: str | None = None) -> tuple[list[Income], int]:
        ...

    def get_income_summary(self,min_expense: Decimal | None = None) -> list[dict]:
        ...


class ExpenseRepositoryInterface(Protocol):
    def get_by_id(self, expense_id: int) -> Expense | None:
        ...

    def get_by_income_id(self, income_id: int) -> list[Expense]:
        ...

    def get_total_by_income_id(self, income_id: int):
        ...

    def create(self, expense: Expense) -> Expense:
        ...

    def update(self, expense: Expense) -> Expense:
        ...

    def delete(self, expense: Expense) -> None:
        ...

    def get_income_expenses_inner_join(self):
        ...

    def get_income_expenses_outer_join(self):
        ...